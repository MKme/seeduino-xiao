# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

"""This example turns on the little red LED."""
from adafruit_circuitplayground import cp

while True:
    cp.red_led = True
